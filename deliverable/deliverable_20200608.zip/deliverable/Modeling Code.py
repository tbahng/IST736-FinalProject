#!/usr/bin/env python
# coding: utf-8

# In[18]:


import os
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import random
import seaborn as sns
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB


# In[2]:


df = pd.read_csv('data/data.csv')


# In[3]:


df.head()


# In[4]:


#removing the websites from tweet data
df['text'] = df['text'].str.replace('http\S+|www.\S+', '', case=False)


# In[5]:


#2020 candidates with 2018 tweets
tweets_2018 = df[(df['created_at'] >= '2018-01-01') & (df['created_at'] < '2018-12-31')]
candidates_2018 = tweets_2018['handle'].unique()
#2020 candidates w/o 2018 tweets
not_2018 = df[~df.handle.isin(candidates_2018)]
candidates_not2018 = not_2018['handle'].unique()


# In[98]:


grouped_2018 = tweets_2018.groupby(by=['handle', 'candidate_2020'], as_index=False).first()
grouped_2018 = grouped_2018[['handle', 'candidate_2020']]
grouped_2018['candidate_2020'] = grouped_2018['candidate_2020'].apply(lambda x: 1 if x is True else 0)

grouped_not_2018 = not_2018.groupby(by=['handle', 'candidate_2020'], as_index=False).first()
grouped_not_2018 = grouped_not_2018[['handle', 'candidate_2020']]
grouped_not_2018['candidate_2020'] = grouped_not_2018['candidate_2020'].apply(lambda x: 1 if x is True else 0)

Y_2018 = grouped_2018.loc[grouped_2018['candidate_2020'] == 1]
N_2018 = grouped_2018.loc[grouped_2018['candidate_2020'] == 0]
Y_N_2018 = grouped_not_2018.loc[grouped_not_2018['candidate_2020'] == 1]
N_N_2018 = grouped_not_2018.loc[grouped_not_2018['candidate_2020'] == 0]

candidate_2018 = pd.DataFrame({'handle': Y_2018['handle'],'x_axis': [random.uniform(0,50) for k in Y_2018.index], 'y_axis':[random.uniform(50, 100) for k in Y_2018.index]}) 
candidate_non2018 = pd.DataFrame({'handle': N_2018['handle'],'x_axis': [random.uniform(50,100) for k in N_2018.index], 'y_axis':[random.uniform(50, 100) for k in N_2018.index]}) 
noncandidate_2018 = pd.DataFrame({'handle': Y_N_2018['handle'],'x_axis': [random.uniform(0,50) for k in Y_N_2018.index], 'y_axis':[random.uniform(0,50) for k in Y_N_2018.index]}) 
noncandidate_non2018 = pd.DataFrame({'handle': N_N_2018['handle'],'x_axis': [random.uniform(50,100) for k in N_N_2018.index], 'y_axis':[random.uniform(0,50) for k in N_N_2018.index]}) 


# In[99]:


plot_df = pd.concat([candidate_2018, candidate_non2018,noncandidate_2018,noncandidate_non2018], axis=0, sort=False)


# In[100]:


get_ipython().run_line_magic('matplotlib', 'inline')
plt.figure(figsize=(25,15))
# Hold activation for multiple lines on same graph
plt.hold('on')
# Set x-axis range
plt.xlim((0,100))
# Set y-axis range
plt.ylim((0,100))
# Draw lines to split quadrants
plt.plot([50,50],[0,100], linewidth=4, color='black' )
plt.plot([0,100],[50,50], linewidth=4, color='black' )
#plt.title('Quadrant plot')

ax = plot_df.set_index('x_axis')['y_axis'].plot(style='o')

for i, point in plot_df.iterrows():
    ax.text(point['x_axis'], point['y_axis'], str(point['handle']))
    
plt.axis('off')
plt.show()


# In[21]:


tweets_2018['x_axis'] = [random.uniform(0,5)for k in tweets_2018.index]


# In[38]:


print("Candidates who tweeted in 2018: ", candidates_2018)
print("Candidates who did not tweet in 2018: ", candidates_not2018)


# In[36]:


#get the average number of tweets for those who tweeted in 2018
count_dist = tweets_2018.groupby('handle')['text'].count().reset_index(name='count')
sns.distplot(count_dist['count'])
print('Median Tweets for Candidates: ', count_dist['count'].median())


# In[37]:


#tweets for those not retrieved from 2018
count_dist = not_2018.groupby('handle')['text'].count().reset_index(name='count')
sns.distplot(count_dist['count'])
print('Median Tweets for Candidates: ', count_dist['count'].median())


# In[41]:


#For those that did not have tweets in 2018, grab the first 450 tweets
not_2018_ordered = not_2018.groupby(["handle"]).apply(lambda x: x.sort_values(["created_at"], ascending = True)).reset_index(drop=True)

#grab the top 450 from everyone
final_not_2018 = not_2018_ordered.groupby('handle').head(450)


# In[42]:


final_not_2018.head()


# In[77]:


#merge the dataframes and convert the target variable
merge_df = pd.concat([final_not_2018, tweets_2018], axis=0, sort=False)
print(merge_df.shape)

final_df = merge_df.groupby('handle').agg({'text':'sum', 'candidate_2020':'first'}).reset_index()

final_df['candidate_2020'] = final_df['candidate_2020'].apply(lambda x: 1 if x is True else 0)
print("Final Dataframe shape: ", final_df.shape)


# In[59]:


final_df.head()


# In[63]:


MyVect5=CountVectorizer(analyzer = 'word',
                        stop_words='english',
                        #token_pattern='(?u)[a-zA-Z]+',
                        #token_pattern=pattern,
                        #tokenizer=LemmaTokenizer(),
                        #strip_accents = 'unicode', 
                        lowercase = True
                        )


# In[64]:


#slightly modified our homework code for the vectorizer. Might want to think about removing numeric columns
FinalDF = pd.DataFrame()
X5 = MyVect5.fit_transform(final_df.text)
ColumnNames2=MyVect5.get_feature_names()
builder=pd.DataFrame(X5.toarray(),columns=ColumnNames2)
builder["Label"]=final_df['candidate_2020']
FinalDF = FinalDF.append(builder)


# In[ ]:


FinalDF.head()


# In[67]:


#train/test split
data_train, data_test = train_test_split(FinalDF, test_size=0.3)


# In[68]:


data_train_input=data_train.drop(["Label"], axis=1)

labels_train=data_train["Label"]

data_test_input = data_test.drop(["Label"], axis=1)

label_test=data_test["Label"]


# In[76]:


MyModelNB= MultinomialNB()

MyModelNB.fit(data_train_input, labels_train)

Prediction = MyModelNB.predict(data_test_input)


print("\nThe prediction from NB is:")
print(Prediction)
print("\nThe actual labels are:")
print(label_test)

cnf_matrix = confusion_matrix(label_test, Prediction)
print("\nThe confusion matrix is:")
print(cnf_matrix)

print(classification_report(label_test, Prediction))


# In[ ]:





# In[ ]:





# In[ ]:




